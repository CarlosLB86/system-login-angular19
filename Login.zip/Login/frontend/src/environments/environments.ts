export const environment = {
  production: false,
  apiUrl: 'http://localhost:3500/api' // Base URL: The root endpoint for the Node.js backend API.
// Centralizing this allows for easy switching between development and production environments.
};